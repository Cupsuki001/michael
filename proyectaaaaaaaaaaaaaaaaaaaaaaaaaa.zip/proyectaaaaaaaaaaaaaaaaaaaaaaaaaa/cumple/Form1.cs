namespace cumple
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTNini_Click(object sender, EventArgs e)
        {
           
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void BTNacep_Click(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form2 j = new Form2();
            j.Show();
            button2.Enabled = true;
            this.Hide();
        }

        private void BTNini_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Hola Michael feliz cumple, como regalo hice este programa para ver si te acuerdas, solo tu sabes la respuesta");
           
            button1.Enabled = true;
        }

        private void BTNsalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
           

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            Frm1.Enabled = false;
            textBox2.Enabled = false;
            button1.Enabled = false;
           
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            

            BTNini.Enabled = false;
            int a = Convert.ToInt16(Frm1.Text);
          
            if(a == 0 || a == 1) 
            {
                label4.Text = "LO SIENTO";
            }
            else if(a == 2 || a == 3) 
            {
                label4.Text = "CASI PELITOS";
            }
            else if(a == 4 || a == 5) 
            {
                label4.Text = "QUE BUENO";
            }
            
        }

        private void Frm1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}