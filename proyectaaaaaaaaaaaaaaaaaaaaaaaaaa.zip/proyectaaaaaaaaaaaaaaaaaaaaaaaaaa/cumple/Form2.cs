﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cumple
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int pun =0;

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            groupBox2.Show();
            groupBox1.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Frm2.Text = "0";
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            label1.Text = "¿Donde nos conocimos?";
            checkBox1.Text = "Iglesia";
            checkBox2.Text = "Parque";
            checkBox3.Text = "Fiesta";
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            checkBox3.Enabled = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            label2.Text = "¿Cuando me quede \n en el ayuno,\n tu me regalastes un:?";
            checkBox4.Text = "Anillo";
            checkBox5.Text = "Collar";
            checkBox6.Text = "Pulsera";
            checkBox4.Enabled = true;
            checkBox5.Enabled = true;
            checkBox6.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = "¿La primera vez \n en el segundo culto,\n  que fue lo que me dijistes?";
            checkBox7.Text = "Sos divertido";
            checkBox8.Text = "Eres tranquilo";
            checkBox9.Text = "Prestame el telefono";
            checkBox7.Enabled = true;
            checkBox8.Enabled = true;
            checkBox9.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
             label4.Text = "¿Cuanto eramos \n del especial de canto?";
            checkBox10.Text = "5";
            checkBox11.Text = "7";
            checkBox12.Text = "6";
            checkBox10.Enabled = true;
            checkBox11.Enabled = true;
            checkBox12.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label5.Text = "¿Cuanto costo la tasa?";
            checkBox13.Text = "c$70";
            checkBox14.Text = "c$60";
            checkBox15.Text = "c$50";
            checkBox13.Enabled = true;
            checkBox14.Enabled = true;
            checkBox15.Enabled = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked == true) 
            {
                pun = pun + 1;
                Frm2.Text = Convert.ToString(pun);
                checkBox1.Enabled = false;
               checkBox2.Enabled = false;
                checkBox3.Enabled = false; 
                button1.Enabled = false;
                button1.Text = "Listo";
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                checkBox2.Enabled =false;   
                checkBox1.Enabled = false;
                checkBox3.Enabled = false;
                button1.Enabled = false;
                button1.Text = "Listo";
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                checkBox3.Enabled = false;
                checkBox1.Enabled = false;
                checkBox2.Enabled = false;
                button1.Enabled = false;
                button1.Text = "Listo";
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                pun = pun + 1;
                Frm2.Text = Convert.ToString(pun);
                checkBox4.Enabled = false;
                checkBox5.Enabled = false;
                checkBox6.Enabled = false;
                button2.Enabled = false;
                button2.Text = "Listo";
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                checkBox6.Enabled = false;
                checkBox4.Enabled = false;
                checkBox5.Enabled = false;
                button2.Enabled = false;
                button2.Text = "Listo";
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
          
                checkBox4.Enabled = false;
                checkBox5.Enabled = false;
                checkBox6.Enabled = false;
                button2.Enabled = false;
                button2.Text = "Listo";
            }
        }

        private void Form2_Load_1(object sender, EventArgs e)
        {
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
            checkBox4.Enabled = false;
            checkBox5.Enabled=false;
            checkBox6.Enabled=false;
            checkBox7.Enabled = false;
            checkBox8.Enabled=false;
            checkBox9.Enabled=false;
            checkBox10.Enabled=false;
            checkBox11.Enabled=false;
            checkBox12.Enabled=false;
            checkBox13.Enabled=false;
            checkBox14.Enabled=false;
            checkBox15.Enabled=false;
           
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                checkBox7.Enabled = false;
                checkBox8.Enabled = false;
                checkBox9.Enabled = false;
                button3.Enabled = false;
                button3.Text = "Listo";
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
            {
                pun = pun + 1;
                Frm2.Text = Convert.ToString(pun);
                checkBox7.Enabled = false;
                checkBox8.Enabled = false;
                checkBox9.Enabled = false;
                button3.Enabled = false;
                button3.Text = "Listo";
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked == true)
            {
                checkBox7.Enabled = false;
                checkBox8.Enabled = false;
                checkBox9.Enabled = false;
                button3.Enabled = false;
                button3.Text = "Listo";
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox10.Checked == true)
            {
                pun = pun + 1;
                Frm2.Text = Convert.ToString(pun);
                checkBox10.Enabled = false;
                checkBox11.Enabled = false;
                checkBox12.Enabled = false;
                button4.Enabled = false;
                button4.Text = "Listo";
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
               
                checkBox10.Enabled = false;
                checkBox11.Enabled = false;
                checkBox12.Enabled = false;
                button4.Enabled = false;
                button4.Text = "Listo";
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox12.Checked == true)
            {

                checkBox10.Enabled = false;
                checkBox11.Enabled = false;
                checkBox12.Enabled = false;
                button4.Enabled = false;
                button4.Text = "Listo";
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked == true)
            {

                checkBox13.Enabled = false;
                checkBox14.Enabled = false;
                checkBox15.Enabled = false;
                button5.Enabled = false;
                button5.Text = "Listo";
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked == true)
            {
                pun = pun + 1;
                Frm2.Text = Convert.ToString(pun);
                checkBox13.Enabled = false;
                checkBox14.Enabled = false;
                checkBox15.Enabled = false;
                button5.Enabled = false;
                button5.Text = "Listo";
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked == true)
            {

                checkBox13.Enabled = false;
                checkBox14.Enabled = false;
                checkBox15.Enabled = false;
                button5.Enabled = false;
                button5.Text = "Listo";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
            Form1 k = new Form1();
            k.Frm1.Text = Frm2.Text;
            
            k.Show();
            this.Close();

        }
    }
}
